
import React, { useState } from 'react';
import { AppView } from '../types';

interface NavbarProps {
  currentView: AppView;
  setView: (view: AppView) => void;
  onSearch: (term: string) => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentView, setView, onSearch }) => {
  const [scrolled, setScrolled] = useState(false);

  React.useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav 
      className={`fixed top-0 z-50 w-full flex items-center justify-between px-6 py-4 transition-all duration-300 ${
        scrolled ? 'bg-black/95 backdrop-blur-md border-b border-white/10' : 'bg-gradient-to-b from-black/80 to-transparent'
      }`}
    >
      <div className="flex items-center gap-10">
        <div 
          className="flex items-center gap-2 cursor-pointer"
          onClick={() => setView(AppView.HOME)}
        >
          <span className="text-primary text-3xl font-black tracking-tighter uppercase italic">FLIXCORE</span>
        </div>
        
        <div className="hidden md:flex items-center gap-6 text-sm font-medium">
          {['Home', 'TV Shows', 'Movies', 'New & Popular', 'My List'].map((item) => (
            <button
              key={item}
              onClick={() => setView(item === 'Home' ? AppView.HOME : AppView.SEARCH)}
              className={`${
                (item === 'Home' && currentView === AppView.HOME) || (item !== 'Home' && currentView === AppView.SEARCH)
                  ? 'text-white'
                  : 'text-gray-400'
              } hover:text-white transition-colors`}
            >
              {item}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="relative group hidden lg:block">
          <div className="flex items-center bg-black/40 border border-white/20 rounded-lg px-3 py-1.5 focus-within:border-primary transition-all">
            <span className="material-symbols-outlined text-gray-400 text-xl">search</span>
            <input 
              className="bg-transparent border-none focus:ring-0 text-sm w-48 placeholder:text-gray-500 text-white" 
              placeholder="Titles, people, genres" 
              type="text"
              onChange={(e) => onSearch(e.target.value)}
              onFocus={() => setView(AppView.SEARCH)}
            />
          </div>
        </div>

        <button className="relative text-gray-400 hover:text-white transition-colors">
          <span className="material-symbols-outlined">notifications</span>
          <span className="absolute top-0 right-0 h-2 w-2 bg-primary rounded-full"></span>
        </button>

        <div className="flex items-center gap-2 cursor-pointer group">
          <div className="w-8 h-8 rounded bg-primary overflow-hidden">
            <img 
              className="w-full h-full object-cover" 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuCkQRyVPUTkwpC8CSEGFUdVVi3e2wZsxh2rCk1sypEnVv270smkRpbB1UFNtS8lY-wRB24UAwJ_HeART-S9ujVch4Xb4_CS61SU2PI7gU5SjE2Renxc6BSm4OgDFPMH_EaIaW-3Q6e8xrC3UbY3BJN5bbyT9FoMDb3KBt_VHk2KQcHWOfLGBSGnCljYlDhMdUpViqF-9N_5KI0IuD0avVTmzWTaaxh7y45PEz0Tzt8Ea6yAOiHYBMObInAbu4AbwJ6YcJ7DRwaY4dI"
              alt="User profile"
            />
          </div>
          <span className="material-symbols-outlined text-sm transition-transform group-hover:rotate-180">arrow_drop_down</span>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
