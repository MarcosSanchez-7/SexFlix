
export interface Actor {
  name: string;
  role: string;
  imageUrl: string;
}

export interface Movie {
  id: string;
  title: string;
  description: string;
  year: number;
  rating: string;
  matchScore: number;
  seasons?: string;
  quality: string;
  posterUrl: string;
  heroUrl: string;
  genre: string;
  cast: Actor[];
  category: 'trending' | 'new' | 'mylist';
}

export enum AppView {
  HOME = 'home',
  DETAILS = 'details',
  SEARCH = 'search'
}
