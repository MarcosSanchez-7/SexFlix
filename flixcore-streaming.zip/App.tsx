
import React, { useState, useMemo } from 'react';
import { Movie, AppView } from './types';
import { MOVIES } from './constants';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import MovieCard from './components/MovieCard';
import MovieGrid from './components/MovieGrid';
import MovieDetails from './components/MovieDetails';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.HOME);
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const trendingMovies = useMemo(() => MOVIES.filter(m => m.category === 'trending'), []);
  const newReleases = useMemo(() => MOVIES.filter(m => m.category === 'new'), []);
  const myList = useMemo(() => MOVIES.filter(m => m.category === 'mylist'), []);

  const filteredMovies = useMemo(() => {
    if (!searchTerm) return MOVIES;
    return MOVIES.filter(m => 
      m.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.genre.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.cast.some(c => c.name.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [searchTerm]);

  const handleMovieClick = (movie: Movie) => {
    setSelectedMovie(movie);
    setCurrentView(AppView.DETAILS);
  };

  const renderContent = () => {
    if (currentView === AppView.DETAILS && selectedMovie) {
      return (
        <MovieDetails 
          movie={selectedMovie} 
          onBack={() => setCurrentView(searchTerm ? AppView.SEARCH : AppView.HOME)} 
          onMovieClick={handleMovieClick}
        />
      );
    }

    if (currentView === AppView.SEARCH) {
      return (
        <MovieGrid 
          title={searchTerm ? `Results for "${searchTerm}"` : 'Browse Gallery'} 
          movies={filteredMovies} 
          onMovieClick={handleMovieClick}
        />
      );
    }

    // Home View
    const heroMovie = MOVIES[0];
    return (
      <main className="relative">
        <Hero movie={heroMovie} onMoreInfo={handleMovieClick} />
        
        <div className="relative z-10 space-y-12 -mt-16 pb-20 px-6 md:px-12">
          {/* Trending Row */}
          <section>
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2 group cursor-pointer">
              Trending Now
              <span className="material-symbols-outlined text-primary opacity-0 group-hover:opacity-100 transition-opacity">chevron_right</span>
            </h2>
            <div className="flex gap-4 overflow-x-auto hide-scrollbar pb-8 -ml-1 pr-12">
              {trendingMovies.map(movie => (
                <MovieCard key={movie.id} movie={movie} onClick={handleMovieClick} />
              ))}
            </div>
          </section>

          {/* New Releases Row */}
          <section>
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2 group cursor-pointer">
              New Releases
              <span className="material-symbols-outlined text-primary opacity-0 group-hover:opacity-100 transition-opacity">chevron_right</span>
            </h2>
            <div className="flex gap-4 overflow-x-auto hide-scrollbar pb-8 -ml-1 pr-12">
              {newReleases.map(movie => (
                <MovieCard key={movie.id} movie={movie} onClick={handleMovieClick} />
              ))}
            </div>
          </section>

          {/* My List Row */}
          <section>
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2 group cursor-pointer">
              My List
              <span className="material-symbols-outlined text-primary opacity-0 group-hover:opacity-100 transition-opacity">chevron_right</span>
            </h2>
            <div className="flex gap-4 overflow-x-auto hide-scrollbar pb-8 -ml-1 pr-12">
              {myList.map(movie => (
                <MovieCard key={movie.id} movie={movie} onClick={handleMovieClick} />
              ))}
            </div>
          </section>
        </div>
      </main>
    );
  };

  return (
    <div className="min-h-screen bg-background font-sans text-white">
      <Navbar 
        currentView={currentView} 
        setView={setCurrentView} 
        onSearch={setSearchTerm} 
      />
      {renderContent()}
      
      <footer className="bg-background py-16 px-12 border-t border-white/10 mt-auto">
        <div className="max-w-4xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 text-sm text-gray-500">
          <ul className="space-y-3">
            <li className="hover:underline cursor-pointer">Audio Description</li>
            <li className="hover:underline cursor-pointer">Investor Relations</li>
            <li className="hover:underline cursor-pointer">Legal Notices</li>
          </ul>
          <ul className="space-y-3">
            <li className="hover:underline cursor-pointer">Help Center</li>
            <li className="hover:underline cursor-pointer">Jobs</li>
            <li className="hover:underline cursor-pointer">Cookie Preferences</li>
          </ul>
          <ul className="space-y-3">
            <li className="hover:underline cursor-pointer">Gift Cards</li>
            <li className="hover:underline cursor-pointer">Terms of Use</li>
            <li className="hover:underline cursor-pointer">Corporate Information</li>
          </ul>
          <ul className="space-y-3">
            <li className="hover:underline cursor-pointer">Media Center</li>
            <li className="hover:underline cursor-pointer">Privacy</li>
            <li className="hover:underline cursor-pointer">Contact Us</li>
          </ul>
        </div>
        <div className="mt-12 flex flex-col items-center gap-4">
          <div className="flex gap-6 text-gray-400">
             <span className="material-symbols-outlined cursor-pointer hover:text-white">public</span>
             <span className="material-symbols-outlined cursor-pointer hover:text-white">brand_family</span>
             <span className="material-symbols-outlined cursor-pointer hover:text-white">video_camera_front</span>
          </div>
          <p className="text-[10px] text-gray-600 uppercase tracking-widest">© 2024 FLIXCORE Entertainment Inc.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;
